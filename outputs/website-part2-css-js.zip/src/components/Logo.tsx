import React, { useEffect, useRef } from 'react';

interface LogoProps {
  size?: 'sm' | 'md' | 'lg';
}

export function Logo({ size = 'md' }: LogoProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const sizes = {
    sm: { width: 100, height: 32 },
    md: { width: 120, height: 38 },
    lg: { width: 150, height: 48 },
  };

  const { width, height } = sizes[size];
  const scale = width / 200;

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const dpr = Math.min(window.devicePixelRatio || 1, 3);
    canvas.width = width * dpr;
    canvas.height = height * dpr;
    canvas.style.width = `${width}px`;
    canvas.style.height = `${height}px`;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = 'high';

    const centerX = 40 * scale;
    const centerY = 28 * scale;
    const planetRadius = 14 * scale;
    const rx = 32 * scale;
    const ry = 8 * scale;
    const rotation = -20 * (Math.PI / 180);

    let angle = 0;

    const drawPlanet = () => {
      const gradient = ctx.createRadialGradient(centerX, centerY, 0, centerX, centerY, planetRadius);
      gradient.addColorStop(0, '#1A1A3E');
      gradient.addColorStop(0.6, '#0F0F2A');
      gradient.addColorStop(1, '#0A0A1A');

      ctx.beginPath();
      ctx.arc(centerX, centerY, planetRadius, 0, Math.PI * 2);
      ctx.fillStyle = gradient;
      ctx.fill();
      ctx.strokeStyle = '#8B5CF6';
      ctx.lineWidth = 1.5;
      ctx.stroke();

      ctx.save();
      ctx.translate(centerX, centerY);

      ctx.strokeStyle = '#8B5CF6';
      ctx.lineWidth = 0.6;
      ctx.globalAlpha = 0.5;

      ctx.beginPath();
      ctx.ellipse(0, 0, planetRadius, planetRadius * 0.4, 0, 0, Math.PI * 2);
      ctx.stroke();

      ctx.beginPath();
      ctx.ellipse(0, 0, planetRadius * 0.4, planetRadius, 0, 0, Math.PI * 2);
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(-planetRadius, 0);
      ctx.lineTo(planetRadius, 0);
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(0, -planetRadius);
      ctx.lineTo(0, planetRadius);
      ctx.stroke();

      ctx.globalAlpha = 0.4;
      ctx.fillStyle = '#3B82F6';
      ctx.beginPath();
      ctx.arc(-5 * scale, -4 * scale, 2.5 * scale, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.arc(8 * scale, 2 * scale, 1.8 * scale, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.arc(-2 * scale, 6 * scale, 1.2 * scale, 0, Math.PI * 2);
      ctx.fill();

      ctx.restore();
    };

    const drawRing = (isBack: boolean) => {
      ctx.save();
      ctx.translate(centerX, centerY);
      ctx.rotate(rotation);

      const gradient = ctx.createLinearGradient(-rx, -ry, rx, ry);
      gradient.addColorStop(0, '#00D4FF');
      gradient.addColorStop(0.5, '#8B5CF6');
      gradient.addColorStop(1, '#00D4FF');

      ctx.beginPath();
      ctx.ellipse(0, 0, rx, ry, 0, 0, Math.PI * 2);
      ctx.strokeStyle = gradient;
      ctx.lineWidth = 1.5;
      ctx.globalAlpha = isBack ? 0.6 : 0.9;

      if (isBack) {
        ctx.clip(new Path2D('M -100 -100 L 100 -100 L 100 0 L -100 0 Z'), 'nonzero');
      } else {
        ctx.clip(new Path2D('M -100 0 L 100 0 L 100 100 L -100 100 Z'), 'nonzero');
      }

      ctx.stroke();

      if (!isBack) {
        ctx.beginPath();
        ctx.ellipse(0, 0, rx + 2.5 * scale, ry + 1.8 * scale, 0, 0, Math.PI * 2);
        ctx.strokeStyle = '#8B5CF6';
        ctx.lineWidth = 0.5;
        ctx.globalAlpha = 0.4;
        ctx.stroke();
      }

      ctx.restore();
    };

    const drawLobster = (x: number, y: number) => {
      ctx.save();
      ctx.translate(centerX, centerY);
      ctx.rotate(rotation);
      ctx.translate(x, y);
      ctx.rotate(-rotation + 60 * (Math.PI / 180));
      ctx.scale(0.085 * scale, 0.085 * scale);

      const gradient = ctx.createLinearGradient(-20, -40, 20, 50);
      gradient.addColorStop(0, '#FF6B6B');
      gradient.addColorStop(1, '#EE5A5A');

      ctx.fillStyle = gradient;
      ctx.beginPath();
      ctx.ellipse(0, 15, 12, 18, 0, 0, Math.PI * 2);
      ctx.fill();

      ctx.beginPath();
      ctx.ellipse(0, -8, 10, 12, 0, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = '#FFF';
      ctx.beginPath();
      ctx.arc(-4, -14, 3, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.arc(4, -14, 3, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = '#000';
      ctx.beginPath();
      ctx.arc(-4, -14, 1.5, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.arc(4, -14, 1.5, 0, Math.PI * 2);
      ctx.fill();

      ctx.strokeStyle = '#FF6B6B';
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.moveTo(-3, -18);
      ctx.quadraticCurveTo(-12, -35, -18, -42);
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(3, -18);
      ctx.quadraticCurveTo(12, -35, 18, -42);
      ctx.stroke();

      ctx.save();
      ctx.translate(-16, -5);
      ctx.fillStyle = gradient;
      ctx.beginPath();
      ctx.ellipse(0, 0, 7, 10, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#FF8E8E';
      ctx.beginPath();
      ctx.moveTo(-4, -6);
      ctx.lineTo(-10, -12);
      ctx.lineTo(-6, -3);
      ctx.closePath();
      ctx.fill();
      ctx.restore();

      ctx.save();
      ctx.translate(16, -5);
      ctx.fillStyle = gradient;
      ctx.beginPath();
      ctx.ellipse(0, 0, 7, 10, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#FF8E8E';
      ctx.beginPath();
      ctx.moveTo(4, -6);
      ctx.lineTo(10, -12);
      ctx.lineTo(6, -3);
      ctx.closePath();
      ctx.fill();
      ctx.restore();

      ctx.strokeStyle = '#FF6B6B';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(-10, 8);
      ctx.quadraticCurveTo(-22, 12, -26, 22);
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(-10, 18);
      ctx.quadraticCurveTo(-20, 22, -24, 32);
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(-10, 28);
      ctx.quadraticCurveTo(-18, 32, -22, 42);
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(10, 8);
      ctx.quadraticCurveTo(22, 12, 26, 22);
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(10, 18);
      ctx.quadraticCurveTo(20, 22, 24, 32);
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(10, 28);
      ctx.quadraticCurveTo(18, 32, 22, 42);
      ctx.stroke();

      ctx.save();
      ctx.translate(0, 35);
      ctx.fillStyle = gradient;
      ctx.beginPath();
      ctx.ellipse(0, 0, 8, 6, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.ellipse(0, 8, 6, 5, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.ellipse(0, 15, 4, 3, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();

      ctx.restore();
    };

    const drawText = () => {
      const textX = 78 * scale;

      ctx.save();
      ctx.shadowColor = 'rgba(139, 92, 246, 0.5)';
      ctx.shadowBlur = 4;

      const textGradient = ctx.createLinearGradient(textX, 0, textX + 80 * scale, 0);
      textGradient.addColorStop(0, '#8B5CF6');
      textGradient.addColorStop(1, '#3B82F6');

      ctx.font = `bold ${13 * scale}px system-ui, -apple-system, sans-serif`;
      ctx.fillStyle = textGradient;
      const englishWidth = ctx.measureText('ClawPlanet').width;
      ctx.fillText('ClawPlanet', textX, 22 * scale);

      ctx.font = `bold ${15 * scale}px system-ui, -apple-system, sans-serif`;
      ctx.fillStyle = '#FFFFFF';
      ctx.globalAlpha = 0.9;

      const chineseText = '虾 蛋 星 球';
      const chineseWidth = ctx.measureText(chineseText).width;
      const startX = textX + (englishWidth - chineseWidth) / 2;
      ctx.fillText(chineseText, startX, 44 * scale);
      ctx.globalAlpha = 1;

      ctx.restore();
    };

    const animate = () => {
      ctx.clearRect(0, 0, width, height);

      drawRing(true);
      drawPlanet();
      drawRing(false);

      const lobsterX = Math.cos(angle) * rx;
      const lobsterY = Math.sin(angle) * ry;
      drawLobster(lobsterX, lobsterY);

      drawText();

      angle += 0.005;

      requestAnimationFrame(animate);
    };

    animate();
  }, [width, height, scale]);

  return (
    <canvas
      ref={canvasRef}
      width={width}
      height={height}
      className="w-full h-full"
      style={{ filter: 'drop-shadow(0 0 12px rgba(139, 92, 246, 0.4))' }}
    />
  );
}
