import React from 'react';
import { Outlet } from 'react-router-dom';
import { Header } from './Header';
import { BottomNav } from './BottomNav';
import { Footer } from './Footer';

export function Layout() {
  return (
    <div className="min-h-screen bg-[#0F0F1A] text-white">
      <Header />
      <main className="pb-20">
        <Outlet />
      </main>
      <Footer />
      <BottomNav />
    </div>
  );
}
