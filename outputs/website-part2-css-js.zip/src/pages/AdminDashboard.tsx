import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Users, Wrench, MessageSquare, Eye, CheckCircle, XCircle, Clock, Shield,
  Code, Award, DollarSign, Briefcase, TrendingUp, ChevronRight, AlertCircle,
  UserCheck, UserX, Settings, BarChart3, Lock
} from 'lucide-react';
import { supabase } from '../supabase/client';
import type { Tables } from '../supabase/types';

type Tool = Tables<'tools'>;
type Profile = Tables<'profiles'>;
type Comment = Tables<'comments'>;
type DeveloperApplication = Tables<'developer_applications'>;
type Promoter = Tables<'promoters'>;
type CommissionWithdrawal = Tables<'commission_withdrawals'>;

interface ToolWithDeveloper extends Tool {
  developer?: Profile;
}

interface ApplicationWithUser extends DeveloperApplication {
  user?: Profile;
}

type AdminTab = 'overview' | 'tools' | 'applications' | 'promoters' | 'withdrawals' | 'users';

export function AdminDashboard() {
  const [activeTab, setActiveTab] = useState<AdminTab>('overview');
  const [pendingTools, setPendingTools] = useState<ToolWithDeveloper[]>([]);
  const [applications, setApplications] = useState<ApplicationWithUser[]>([]);
  const [promoters, setPromoters] = useState<(Promoter & { profile?: Profile })[]>([]);
  const [withdrawals, setWithdrawals] = useState<(CommissionWithdrawal & { promoter?: Promoter & { profile?: Profile } })[]>([]);
  const [users, setUsers] = useState<Profile[]>([]);
  const [stats, setStats] = useState({
    totalUsers: 0,
    totalTools: 0,
    pendingTools: 0,
    pendingApplications: 0,
    totalPromoters: 0,
    pendingWithdrawals: 0,
    totalComments: 0,
    totalViews: 0,
  });
  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    checkAdmin();
  }, []);

  async function checkAdmin() {
    const { data: { user } } = await supabase.auth.getUser();
    if (user) {
      const { data: profile } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user.id)
        .single();

      if (profile?.role === 'admin') {
        setIsAdmin(true);
        fetchAllData();
      } else {
        setLoading(false);
      }
    } else {
      setLoading(false);
    }
  }

  async function fetchAllData() {
    try {
      await Promise.all([
        fetchPendingTools(),
        fetchApplications(),
        fetchPromoters(),
        fetchWithdrawals(),
        fetchStats(),
      ]);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  }

  async function fetchPendingTools() {
    const { data } = await supabase
      .from('tools')
      .select('*, developer:developer_id(*)')
      .eq('status', 'pending')
      .order('created_at', { ascending: false });
    if (data) setPendingTools(data);
  }

  async function fetchApplications() {
    const { data } = await supabase
      .from('developer_applications')
      .select('*, user:user_id(*)')
      .eq('status', 'pending')
      .order('applied_at', { ascending: false });
    if (data) setApplications(data);
  }

  async function fetchPromoters() {
    const { data } = await supabase
      .from('promoters')
      .select('*, profile:user_id(*)')
      .order('joined_at', { ascending: false });
    if (data) setPromoters(data);
  }

  async function fetchWithdrawals() {
    const { data } = await supabase
      .from('commission_withdrawals')
      .select('*, promoter:promoter_id(*, profile:user_id(*))')
      .eq('status', 'pending')
      .order('created_at', { ascending: false });
    if (data) setWithdrawals(data);
  }

  async function fetchStats() {
    const { count: usersCount } = await supabase
      .from('profiles')
      .select('*', { count: 'exact', head: true });

    const { count: toolsCount } = await supabase
      .from('tools')
      .select('*', { count: 'exact', head: true });

    const { count: pendingToolsCount } = await supabase
      .from('tools')
      .select('*', { count: 'exact', head: true })
      .eq('status', 'pending');

    const { count: pendingAppsCount } = await supabase
      .from('developer_applications')
      .select('*', { count: 'exact', head: true })
      .eq('status', 'pending');

    const { count: promotersCount } = await supabase
      .from('promoters')
      .select('*', { count: 'exact', head: true });

    const { count: pendingWithdrawalsCount } = await supabase
      .from('commission_withdrawals')
      .select('*', { count: 'exact', head: true })
      .eq('status', 'pending');

    const { count: commentsCount } = await supabase
      .from('comments')
      .select('*', { count: 'exact', head: true });

    const { data: toolsStats } = await supabase
      .from('tools')
      .select('view_count');

    const totalViews = toolsStats?.reduce((sum, tool) => sum + (tool.view_count || 0), 0) || 0;

    setStats({
      totalUsers: usersCount || 0,
      totalTools: toolsCount || 0,
      pendingTools: pendingToolsCount || 0,
      pendingApplications: pendingAppsCount || 0,
      totalPromoters: promotersCount || 0,
      pendingWithdrawals: pendingWithdrawalsCount || 0,
      totalComments: commentsCount || 0,
      totalViews: totalViews,
    });
  }

  async function handleApproveTool(toolId: string) {
    const { error } = await supabase
      .from('tools')
      .update({ status: 'approved' })
      .eq('id', toolId);

    if (!error) {
      setPendingTools(pendingTools.filter(tool => tool.id !== toolId));
      setStats({ ...stats, pendingTools: stats.pendingTools - 1 });
    }
  }

  async function handleRejectTool(toolId: string) {
    const { error } = await supabase
      .from('tools')
      .update({ status: 'rejected' })
      .eq('id', toolId);

    if (!error) {
      setPendingTools(pendingTools.filter(tool => tool.id !== toolId));
      setStats({ ...stats, pendingTools: stats.pendingTools - 1 });
    }
  }

  async function handleApproveApplication(appId: string, userId: string) {
    const { error: updateError } = await supabase
      .from('developer_applications')
      .update({ status: 'approved', reviewed_at: new Date().toISOString() })
      .eq('id', appId);

    if (!updateError) {
      await supabase
        .from('profiles')
        .update({ role: 'developer' })
        .eq('id', userId);

      setApplications(applications.filter(app => app.id !== appId));
      setStats({ ...stats, pendingApplications: stats.pendingApplications - 1 });
    }
  }

  async function handleRejectApplication(appId: string) {
    const { error } = await supabase
      .from('developer_applications')
      .update({ status: 'rejected', reviewed_at: new Date().toISOString() })
      .eq('id', appId);

    if (!error) {
      setApplications(applications.filter(app => app.id !== appId));
      setStats({ ...stats, pendingApplications: stats.pendingApplications - 1 });
    }
  }

  async function handleApproveWithdrawal(withdrawalId: string) {
    const { error } = await supabase
      .from('commission_withdrawals')
      .update({ status: 'completed', processed_at: new Date().toISOString() })
      .eq('id', withdrawalId);

    if (!error) {
      setWithdrawals(withdrawals.filter(w => w.id !== withdrawalId));
      setStats({ ...stats, pendingWithdrawals: stats.pendingWithdrawals - 1 });
    }
  }

  async function handleRejectWithdrawal(withdrawalId: string, reason: string) {
    const { error } = await supabase
      .from('commission_withdrawals')
      .update({
        status: 'rejected',
        processed_at: new Date().toISOString(),
        rejection_reason: reason
      })
      .eq('id', withdrawalId);

    if (!error) {
      setWithdrawals(withdrawals.filter(w => w.id !== withdrawalId));
      setStats({ ...stats, pendingWithdrawals: stats.pendingWithdrawals - 1 });
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen pt-20">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#8B5CF6]"></div>
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="pt-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="flex flex-col items-center justify-center min-h-[60vh]">
          <div className="w-16 h-16 rounded-2xl bg-red-500/20 flex items-center justify-center mb-4">
            <Lock className="w-8 h-8 text-red-400" />
          </div>
          <h2 className="text-2xl font-bold mb-2">无权访问</h2>
          <p className="text-white/60">你没有管理员权限</p>
        </div>
      </div>
    );
  }

  const tabs = [
    { id: 'overview', label: '概览', icon: BarChart3 },
    { id: 'tools', label: '工具审核', icon: Wrench, badge: stats.pendingTools },
    { id: 'applications', label: '开发者申请', icon: Briefcase, badge: stats.pendingApplications },
    { id: 'promoters', label: '星推官', icon: Award },
    { id: 'withdrawals', label: '提现审核', icon: DollarSign, badge: stats.pendingWithdrawals },
    { id: 'users', label: '用户管理', icon: Users },
  ];

  return (
    <div className="pt-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto pb-20">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <div className="flex items-center space-x-3 mb-2">
          <div className="w-10 h-10 rounded-xl bg-red-500/20 flex items-center justify-center">
            <Shield className="w-5 h-5 text-red-400" />
          </div>
          <div>
            <h1 className="text-3xl font-bold">管理员后台</h1>
            <p className="text-white/60">平台数据概览和用户管理</p>
          </div>
        </div>
      </motion.div>

      {/* Tab Navigation */}
      <div className="flex flex-wrap gap-2 mb-8">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as AdminTab)}
            className={`flex items-center space-x-2 px-4 py-2 rounded-xl font-medium transition-all ${
              activeTab === tab.id
                ? 'bg-gradient-to-r from-[#8B5CF6] to-[#3B82F6] text-white'
                : 'bg-[#1A1A2E] border border-white/10 text-white/60 hover:text-white hover:border-white/30'
            }`}
          >
            <tab.icon className="w-4 h-4" />
            <span>{tab.label}</span>
            {tab.badge && tab.badge > 0 && (
              <span className="ml-1 px-2 py-0.5 bg-red-500 text-white text-xs rounded-full">
                {tab.badge}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* Content */}
      <AnimatePresence mode="wait">
        {activeTab === 'overview' && (
          <OverviewTab key="overview" stats={stats} />
        )}
        {activeTab === 'tools' && (
          <ToolsTab
            key="tools"
            tools={pendingTools}
            onApprove={handleApproveTool}
            onReject={handleRejectTool}
          />
        )}
        {activeTab === 'applications' && (
          <ApplicationsTab
            key="applications"
            applications={applications}
            onApprove={handleApproveApplication}
            onReject={handleRejectApplication}
          />
        )}
        {activeTab === 'promoters' && (
          <PromotersTab key="promoters" promoters={promoters} />
        )}
        {activeTab === 'withdrawals' && (
          <WithdrawalsTab
            key="withdrawals"
            withdrawals={withdrawals}
            onApprove={handleApproveWithdrawal}
            onReject={handleRejectWithdrawal}
          />
        )}
        {activeTab === 'users' && (
          <UsersTab key="users" users={users} />
        )}
      </AnimatePresence>
    </div>
  );
}

function OverviewTab({ stats }: { stats: any }) {
  const statCards = [
    { label: '总用户数', value: stats.totalUsers, icon: Users, color: 'from-[#8B5CF6] to-[#3B82F6]' },
    { label: '总工具数', value: stats.totalTools, icon: Wrench, color: 'from-[#3B82F6] to-[#06B6D4]' },
    { label: '待审核工具', value: stats.pendingTools, icon: Clock, color: 'from-yellow-500 to-orange-500' },
    { label: '待审核申请', value: stats.pendingApplications, icon: Briefcase, color: 'from-orange-500 to-red-500' },
    { label: '星推官数', value: stats.totalPromoters, icon: Award, color: 'from-green-500 to-emerald-500' },
    { label: '待处理提现', value: stats.pendingWithdrawals, icon: DollarSign, color: 'from-red-500 to-pink-500' },
    { label: '总评论数', value: stats.totalComments, icon: MessageSquare, color: 'from-purple-500 to-pink-500' },
    { label: '总浏览量', value: stats.totalViews, icon: Eye, color: 'from-pink-500 to-rose-500' },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
    >
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {statCards.map((card, index) => (
          <motion.div
            key={card.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05 }}
            className="bg-[#1A1A2E] border border-white/10 rounded-2xl p-6"
          >
            <div className={`w-10 h-10 rounded-xl bg-gradient-to-r ${card.color} bg-opacity-20 flex items-center justify-center mb-4`}>
              <card.icon className="w-5 h-5 text-white" />
            </div>
            <p className="text-sm text-white/60 mb-1">{card.label}</p>
            <p className="text-2xl font-bold">{card.value.toLocaleString()}</p>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
}

function ToolsTab({ tools, onApprove, onReject }: { tools: ToolWithDeveloper[], onApprove: (id: string) => void, onReject: (id: string) => void }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
    >
      <h2 className="text-xl font-bold mb-6 flex items-center">
        <Clock className="w-5 h-5 mr-2 text-[#8B5CF6]" />
        待审核工具
        <span className="ml-2 text-sm text-white/40">({tools.length})</span>
      </h2>

      <div className="space-y-4">
        {tools.map((tool, index) => (
          <motion.div
            key={tool.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05 }}
            className="bg-[#1A1A2E] border border-white/10 rounded-2xl p-6"
          >
            <div className="flex items-start justify-between">
              <div className="flex items-start space-x-4">
                <div className="w-16 h-16 rounded-xl bg-gradient-to-br from-[#8B5CF6]/20 to-[#3B82F6]/20 flex items-center justify-center">
                  {tool.icon_url ? (
                    <img src={tool.icon_url} alt={tool.name} className="w-12 h-12 rounded-lg" />
                  ) : (
                    <Wrench className="w-8 h-8 text-[#8B5CF6]" />
                  )}
                </div>
                <div>
                  <h3 className="font-bold text-lg mb-1">{tool.name}</h3>
                  <p className="text-white/60 text-sm mb-2">{tool.description}</p>
                  <div className="flex items-center space-x-4 text-sm text-white/40">
                    <span>开发者: {tool.developer?.username || '未知'}</span>
                    <span>类型: {tool.jump_type}</span>
                    <span>提交时间: {new Date(tool.created_at || '').toLocaleDateString()}</span>
                  </div>
                </div>
              </div>
              <div className="flex space-x-3">
                <button
                  onClick={() => onApprove(tool.id!)}
                  className="flex items-center space-x-2 px-4 py-2 bg-green-500/20 text-green-400 rounded-xl hover:bg-green-500/30 transition-colors"
                >
                  <CheckCircle className="w-4 h-4" />
                  <span>通过</span>
                </button>
                <button
                  onClick={() => onReject(tool.id!)}
                  className="flex items-center space-x-2 px-4 py-2 bg-red-500/20 text-red-400 rounded-xl hover:bg-red-500/30 transition-colors"
                >
                  <XCircle className="w-4 h-4" />
                  <span>拒绝</span>
                </button>
              </div>
            </div>
          </motion.div>
        ))}
        {tools.length === 0 && (
          <div className="text-center py-12 text-white/40">
            <CheckCircle className="w-16 h-16 mx-auto mb-4 text-green-400" />
            <p>没有待审核的工具</p>
          </div>
        )}
      </div>
    </motion.div>
  );
}

function ApplicationsTab({ applications, onApprove, onReject }: { applications: ApplicationWithUser[], onApprove: (id: string, userId: string) => void, onReject: (id: string) => void }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
    >
      <h2 className="text-xl font-bold mb-6 flex items-center">
        <Briefcase className="w-5 h-5 mr-2 text-[#8B5CF6]" />
        待审核开发者申请
        <span className="ml-2 text-sm text-white/40">({applications.length})</span>
      </h2>

      <div className="space-y-4">
        {applications.map((app, index) => (
          <motion.div
            key={app.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05 }}
            className="bg-[#1A1A2E] border border-white/10 rounded-2xl p-6"
          >
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <div className="flex items-center space-x-3 mb-2">
                  <h3 className="font-bold text-lg">{app.contact_name}</h3>
                  {app.company_name && (
                    <span className="text-sm text-white/60">({app.company_name})</span>
                  )}
                </div>
                <p className="text-white/60 text-sm mb-2">{app.bio}</p>
                <div className="flex items-center space-x-4 text-sm text-white/40">
                  <span>申请人: {app.user?.username || '未知'}</span>
                  <span>电话: {app.contact_phone || '未填写'}</span>
                  <span>申请时间: {new Date(app.applied_at || '').toLocaleDateString()}</span>
                </div>
                {app.portfolio_url && (
                  <a
                    href={app.portfolio_url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center text-sm text-[#8B5CF6] hover:underline mt-2"
                  >
                    查看作品集 <ChevronRight className="w-4 h-4 ml-1" />
                  </a>
                )}
              </div>
              <div className="flex space-x-3">
                <button
                  onClick={() => onApprove(app.id!, app.user_id)}
                  className="flex items-center space-x-2 px-4 py-2 bg-green-500/20 text-green-400 rounded-xl hover:bg-green-500/30 transition-colors"
                >
                  <UserCheck className="w-4 h-4" />
                  <span>通过</span>
                </button>
                <button
                  onClick={() => onReject(app.id!)}
                  className="flex items-center space-x-2 px-4 py-2 bg-red-500/20 text-red-400 rounded-xl hover:bg-red-500/30 transition-colors"
                >
                  <UserX className="w-4 h-4" />
                  <span>拒绝</span>
                </button>
              </div>
            </div>
          </motion.div>
        ))}
        {applications.length === 0 && (
          <div className="text-center py-12 text-white/40">
            <CheckCircle className="w-16 h-16 mx-auto mb-4 text-green-400" />
            <p>没有待审核的申请</p>
          </div>
        )}
      </div>
    </motion.div>
  );
}

function PromotersTab({ promoters }: { promoters: (Promoter & { profile?: Profile })[] }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
    >
      <h2 className="text-xl font-bold mb-6 flex items-center">
        <Award className="w-5 h-5 mr-2 text-[#8B5CF6]" />
        星推官列表
        <span className="ml-2 text-sm text-white/40">({promoters.length})</span>
      </h2>

      <div className="space-y-4">
        {promoters.map((promoter, index) => (
          <motion.div
            key={promoter.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05 }}
            className="bg-[#1A1A2E] border border-white/10 rounded-2xl p-6"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-[#F59E0B]/20 to-[#EF4444]/20 flex items-center justify-center">
                  <Award className="w-6 h-6 text-[#F59E0B]" />
                </div>
                <div>
                  <h3 className="font-bold">{promoter.profile?.username || '未知用户'}</h3>
                  <p className="text-sm text-white/60">
                    加入时间: {new Date(promoter.joined_at || '').toLocaleDateString()}
                  </p>
                </div>
              </div>
              <div className="flex items-center space-x-6 text-sm">
                <div className="text-center">
                  <p className="text-white/40">佣金比例</p>
                  <p className="font-bold text-[#F59E0B]">{promoter.commission_rate}%</p>
                </div>
                <div className="text-center">
                  <p className="text-white/40">累计收益</p>
                  <p className="font-bold text-green-400">¥{promoter.total_earned?.toFixed(2) || '0.00'}</p>
                </div>
                <div className="text-center">
                  <p className="text-white/40">已提现</p>
                  <p className="font-bold">¥{promoter.total_withdrawn?.toFixed(2) || '0.00'}</p>
                </div>
                <span className={`px-3 py-1 rounded-full text-xs ${
                  promoter.status === 'active'
                    ? 'bg-green-500/20 text-green-400'
                    : 'bg-red-500/20 text-red-400'
                }`}>
                  {promoter.status === 'active' ? '正常' : '已冻结'}
                </span>
              </div>
            </div>
          </motion.div>
        ))}
        {promoters.length === 0 && (
          <div className="text-center py-12 text-white/40">
            <Award className="w-16 h-16 mx-auto mb-4 text-[#F59E0B]" />
            <p>暂无星推官</p>
          </div>
        )}
      </div>
    </motion.div>
  );
}

function WithdrawalsTab({ withdrawals, onApprove, onReject }: { withdrawals: any[], onApprove: (id: string) => void, onReject: (id: string, reason: string) => void }) {
  const [rejectReason, setRejectReason] = useState('');
  const [rejectingId, setRejectingId] = useState<string | null>(null);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
    >
      <h2 className="text-xl font-bold mb-6 flex items-center">
        <DollarSign className="w-5 h-5 mr-2 text-[#8B5CF6]" />
        待处理提现申请
        <span className="ml-2 text-sm text-white/40">({withdrawals.length})</span>
      </h2>

      <div className="space-y-4">
        {withdrawals.map((withdrawal, index) => (
          <motion.div
            key={withdrawal.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.05 }}
            className="bg-[#1A1A2E] border border-white/10 rounded-2xl p-6"
          >
            <div className="flex items-start justify-between">
              <div>
                <div className="flex items-center space-x-3 mb-2">
                  <h3 className="font-bold text-lg">{withdrawal.promoter?.profile?.username || '未知用户'}</h3>
                  <span className="text-2xl font-bold text-green-400">¥{withdrawal.amount?.toFixed(2)}</span>
                </div>
                <div className="flex items-center space-x-4 text-sm text-white/40">
                  <span>支付方式: {withdrawal.payment_method || '未指定'}</span>
                  <span>账号: {withdrawal.payment_account || '未填写'}</span>
                  <span>申请时间: {new Date(withdrawal.created_at || '').toLocaleDateString()}</span>
                </div>
              </div>
              <div className="flex space-x-3">
                {rejectingId === withdrawal.id ? (
                  <div className="flex items-center space-x-2">
                    <input
                      type="text"
                      value={rejectReason}
                      onChange={(e) => setRejectReason(e.target.value)}
                      placeholder="拒绝原因"
                      className="px-3 py-2 bg-[#0F0F1A] border border-white/10 rounded-lg text-sm"
                    />
                    <button
                      onClick={() => {
                        onReject(withdrawal.id!, rejectReason);
                        setRejectingId(null);
                        setRejectReason('');
                      }}
                      className="px-3 py-2 bg-red-500 text-white rounded-lg text-sm"
                    >
                      确认
                    </button>
                    <button
                      onClick={() => {
                        setRejectingId(null);
                        setRejectReason('');
                      }}
                      className="px-3 py-2 border border-white/20 rounded-lg text-sm"
                    >
                      取消
                    </button>
                  </div>
                ) : (
                  <>
                    <button
                      onClick={() => onApprove(withdrawal.id!)}
                      className="flex items-center space-x-2 px-4 py-2 bg-green-500/20 text-green-400 rounded-xl hover:bg-green-500/30 transition-colors"
                    >
                      <CheckCircle className="w-4 h-4" />
                      <span>通过</span>
                    </button>
                    <button
                      onClick={() => setRejectingId(withdrawal.id!)}
                      className="flex items-center space-x-2 px-4 py-2 bg-red-500/20 text-red-400 rounded-xl hover:bg-red-500/30 transition-colors"
                    >
                      <XCircle className="w-4 h-4" />
                      <span>拒绝</span>
                    </button>
                  </>
                )}
              </div>
            </div>
          </motion.div>
        ))}
        {withdrawals.length === 0 && (
          <div className="text-center py-12 text-white/40">
            <CheckCircle className="w-16 h-16 mx-auto mb-4 text-green-400" />
            <p>没有待处理的提现申请</p>
          </div>
        )}
      </div>
    </motion.div>
  );
}

function UsersTab({ users }: { users: Profile[] }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
    >
      <h2 className="text-xl font-bold mb-6 flex items-center">
        <Users className="w-5 h-5 mr-2 text-[#8B5CF6]" />
        用户管理
      </h2>
      <p className="text-white/60 text-center py-12">
        用户管理功能开发中...
      </p>
    </motion.div>
  );
}
